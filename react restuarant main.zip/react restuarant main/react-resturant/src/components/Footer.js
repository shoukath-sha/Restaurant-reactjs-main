import React from "react";

const Footer = () => {
  return (
    <>
      <section class="footer">
        <div class="share">
          <a href="https://www.facebook.com/" class="fab fa-facebook-f"></a>
          <a href="https://x.com/?lang=en" class="fab fa-twitter"></a>
          <a href="https://www.instagram.com/" class="fab fa-instagram"></a>
          <a href="https://in.linkedin.com/" class="fab fa-linkedin"></a>
          <a href="https://in.pinterest.com/#top" class="fab fa-pinterest"></a>
        </div>
        <div class="links">
          <a href="/hohme">home</a>
          <a href="/about">about</a>
          <a href="/menu">menu</a>
          <a href="/products">products</a>
          <a href="/review">review</a>
          <a href="/contact">contact</a>
          <a href="/blog">blogs</a>
        </div>
        <div class="credit">
          created by <span>shebi</span> | all rights reserved
        </div>
      </section>
    </>
  );
};

export default Footer;
