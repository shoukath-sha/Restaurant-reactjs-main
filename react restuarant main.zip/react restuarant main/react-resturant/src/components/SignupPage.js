import React, { useState } from 'react';

const SignupPage = () => {
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSignup = (e) => {
    e.preventDefault();
    // Perform signup logic here
    // For demo purposes, just show success message
    setIsSuccess(true);
  };

  return (
    <div style={styles.background}>
      <div style={styles.signupContainer}>
        <h1 style={styles.title}>Welcome to restaurant</h1>
        <p style={styles.subtitle}>Sign up to receive exclusive offers and updates!</p>
        {isSuccess ? (
          <div style={styles.successMessage}>Sign up successful! Check your email for confirmation.</div>
        ) : (
          <form onSubmit={handleSignup}>
            <label style={styles.label} htmlFor="name">Full Name</label>
            <input style={styles.input} type="text" id="name" name="name" required />

            <label style={styles.label} htmlFor="email">Email Address</label>
            <input style={styles.input} type="email" id="email" name="email" required />

            <label style={styles.label} htmlFor="password">Password</label>
            <input style={styles.input} type="password" id="password" name="password" required />

            <button style={styles.button} type="submit">Sign Up</button>
          </form>
        )}
      </div>
    </div>
  );
};

const styles = {
  background: {
    backgroundImage: 'url(restaurant-background.jpg)',
    backgroundSize: 'cover',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    margin: 0,
  },
  signupContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    padding: '20px',
    borderRadius: '10px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
    maxWidth: '400px',
    width: '100%',
    textAlign: 'center',
  },
  title: {
    marginBottom: '10px',
    color: '#333',
  },
  subtitle: {
    marginBottom: '20px',
    color: '#666',
  },
  label: {
    display: 'block',
    margin: '10px 0 5px',
    color: '#333',
  },
  input: {
    width: '100%',
    padding: '10px',
    marginBottom: '20px',
    border: '1px solid #ccc',
    borderRadius: '5px',
  },
  button: {
    backgroundColor: '#ff6347',
    color: 'white',
    padding: '10px 20px',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '16px',
  },
  successMessage: {
    color: 'green',
    marginBottom: '20px',
  },
};

export default SignupPage;

