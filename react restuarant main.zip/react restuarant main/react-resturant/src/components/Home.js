import React from "react";
import { Link } from 'react-router-dom';
import About from './About'
import Menu from './Menu'
import Products from './Products'
import Review from './Review'
import Contact from './Contact'
import Blog from './Blog'

const Home = () => {
  return (
    <>
      <section className="home" id="home">
        <div className="content">
          <h3>
            fresh <span>food in the </span>morning
          </h3>
          <p>
          A restaurant is an establishment where customers pay to enjoy meals prepared and served on-site.
          </p>
          {/* <a href="#SignupPage" className="btn">
            get yours now
          </a> */}
           <Link to="/signup" className="btn">
          get yours now
        </Link>
        </div>
      </section>
      <About/>
      <Menu/>
      <Products/>
      <Review/>
      <Contact/>
      <Blog/>

    </>
  );
};

export default Home;
