import React, { useRef, useState } from "react";
import Logo from "../assets/images/logo.png";
import { Link } from 'react-router-dom';
import { cart } from "../Data";

const Navbar = () => {
  const navbarRef = useRef();
  const searchRef = useRef();
  const cartRef = useRef();
  const [isLoggedIn, setIsLoggedIn] = useState(false); // State to track login status
  const [searchClickCount, setSearchClickCount] = useState(0); // State to track search button clicks

  const navbarHandler = () => {
    navbarRef.current.classList.toggle("active");
    searchRef.current.classList.remove("active");
    cartRef.current.classList.remove("active");
  };

  const searchHandler = () => {
    if (!isLoggedIn && searchClickCount === 1) {
      alert("You are not logged in. Please log in to perform search.");
      return;
    }

    searchRef.current.classList.toggle("active");
    navbarRef.current.classList.remove("active");
    cartRef.current.classList.remove("active");

    setSearchClickCount(prevCount => prevCount + 1);
  };

  const cartHandler = () => {
    cartRef.current.classList.toggle("active");
    searchRef.current.classList.remove("active");
    navbarRef.current.classList.remove("active");
  };

  return (
    <>
      <header className="header">
        <Link to="/" className="logo">
          <img src={Logo} alt="" />
        </Link>
        <nav className="navbar" ref={navbarRef}>
          <Link to="/home">Home</Link>
          <Link to="/about">About</Link>
          <Link to="/menu">Menu</Link>
          <Link to="/products">Products</Link>
          <Link to="/review">Review</Link>
          <Link to="/contact">Contact</Link>
          <Link to="/blogs">Blogs</Link>
        </nav>
        <div className="icons">
          <div
            className="fas fa-search"
            id="search-btn"
            onClick={searchHandler}
          ></div>
          <div
            className="fas fa-shopping-cart"
            id="cart-btn"
            onClick={cartHandler}
          ></div>
          <div
            className="fas fa-bars"
            id="menu-btn"
            onClick={navbarHandler}
          ></div>
        </div>
        <div className="search-form" ref={searchRef}>
          <input type="search" id="search-box" placeholder="search here..." />
          <label htmlFor="search-box" className="fas fa-search" onClick={searchHandler}></label>
        </div>
        <div className="cart-items-container" ref={cartRef}>
          {cart.map((item, index) => (
            <div className="cart-item" key={index * Math.random()}>
              <span className="fas fa-times"></span>
              <img src={item.img} alt="" />
              <div className="content">
                <h3>cart item 01</h3>
                <div className="price">$15.99/-</div>
              </div>
            </div>
          ))}
          <Link to="#" className="btn">
            Checkout Now
          </Link>
        </div>
      </header>
    </>
  );
};

export default Navbar;
