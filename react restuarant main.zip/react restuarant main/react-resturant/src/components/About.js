import React, { useState } from "react";
import AboutImg from "../assets/images/about-img";

const About = () => {
  const [showCommentedParagraph, setShowCommentedParagraph] = useState(false);

  const toggleCommentedParagraph = () => {
    setShowCommentedParagraph(!showCommentedParagraph);
  };

  return (
    <>
      <section className="about" id="about">
        <h1 className="heading">
          <span>about</span> us
        </h1>

        <div className="row">
          <div className="image">
            <img src={AboutImg} alt="" />
          </div>

          <div className="content">
            <h3>what makes our food special?</h3>
            <p>
              A restaurant website serves as a digital window into the culinary
              world, offering visitors a tantalizing glimpse into the flavors,
              ambiance, and hospitality that await them. At its heart lies the
              homepage, a vibrant canvas adorned with images of sumptuous
              dishes, inviting
            </p>
            {showCommentedParagraph && (
              <p>
                interiors, and perhaps a glimpse of the bustling kitchen. Here,
                visitors are welcomed with open arms, greeted by a carefully
                crafted narrative that embodies the essence of the restaurant's
                identity.
              </p>
            )}
            <a  className="btn" onClick={toggleCommentedParagraph}>
              learn more
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;

